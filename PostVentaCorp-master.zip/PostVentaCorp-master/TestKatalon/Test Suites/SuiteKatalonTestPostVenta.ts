<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>SuiteKatalonTestPostVenta</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>8203b8e9-d175-4a6a-bebf-cd5a5d23cef6</testSuiteGuid>
   <testCaseLink>
      <guid>2501d896-a474-4e33-ac5d-d676d9cb2a70</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TestPostVenta</testCaseId>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>27ed541f-d148-493d-8823-a729aceb0a7c</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
